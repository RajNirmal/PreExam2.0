package com.spintum.preexam;

import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.ProgressDialog;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;


public class Login extends Activity implements OnClickListener,
		GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
	private static final int RC_SIGN_IN = 0;
	// Logcat tag
	private static final String TAG = "Slider";

	// Profile pic image size in pixels
	private static final int PROFILE_PIC_SIZE = 400;

	// Google client to interact with Google API
	private GoogleApiClient mGoogleApiClient;

	/**
	 * A flag indicating that a PendingIntent is in progress and prevents us
	 * from starting further intents.
	 */
	private boolean mIntentInProgress;

	private boolean mSignInClicked;

	private ConnectionResult mConnectionResult;

	private SignInButton btnSignIn;
	/*private Button btnSignOut, btnRevokeAccess;
        private ImageView imgProfilePic;
        private TextView txtName, txtEmail;
        private LinearLayout llProfileLayout;*/
	private CallbackManager callbackManager;
	private LoginButton loginButton;
	private TextView btnLogin;
	private ProgressDialog progressDialog;
	User user;

	Button submit,signup;
	TextView forgot;
	EditText username, password;
	boolean completed = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		FacebookSdk.sdkInitialize(getApplicationContext());
		AppEventsLogger.activateApp(this);

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_log);
		if(PrefUtils.getCurrentUser(Login.this) != null){

			Intent homeIntent = new Intent(Login.this, Home.class);

			startActivity(homeIntent);

			finish();
		}
		StrictMode.ThreadPolicy pol = new StrictMode.ThreadPolicy.Builder()
				.permitAll().build();
		StrictMode.setThreadPolicy(pol);

		this.overridePendingTransition(R.layout.fade_in, R.layout.fade_out);

		View decorView = getWindow().getDecorView();
// Hide the status bar.
		int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
		decorView.setSystemUiVisibility(uiOptions);
// Remember that you should never show the action bar if the
// status bar is hidden, so hide that too if necessary.
		ActionBar actionBar = getActionBar();
		actionBar.hide();
		btnSignIn = (SignInButton) findViewById(R.id.btn_sign_in);
		submit = (Button) findViewById(R.id.submit);
		forgot=(TextView)findViewById(R.id.forgot);
		signup = (Button) findViewById(R.id.signup);
		username = (EditText) findViewById(R.id.email);
		password= (EditText) findViewById(R.id.password);
		btnSignIn.setOnClickListener(this);
		mGoogleApiClient = new GoogleApiClient.Builder(this).addApi(Plus.API)
				.addConnectionCallbacks(this).addOnConnectionFailedListener(this)
				.addScope(Plus.SCOPE_PLUS_LOGIN).build();
		username.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				if (!isValidEmail(username.getText().toString())) {

					completed = false;
				} else {

					completed = true;
				}

			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub

			}
		});
		password.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				if (password.getText().toString().length() < 1) {

				} else {
				}
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub

			}
		});
		submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (completed) {
					if (password.getText().toString().length() < 1) {
						AlertDialog.Builder b = new AlertDialog.Builder(
								Login.this);
						b.setTitle("Invalid Password!");
						b.setPositiveButton("Ok",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface arg0,
														int arg1) {
										// TODO Auto-generated method stub

									}
								});
						b.show();
					} else {
						if (loggedIn()) {
							Intent i = new Intent(getApplicationContext(),
									Home.class);
							startActivity(i);
							finish();
						} else {
						}
					}
				} else {
					AlertDialog.Builder b = new AlertDialog.Builder(Login.this);
					b.setTitle("Please Fill in Valid Email!");
					b.setPositiveButton("Ok",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface arg0,
													int arg1) {
									// TODO Auto-generated method stub

								}
							});
					b.show();
				}
			}
		});
		signup.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(),
						MainActivity.class);
				startActivity(i);
				finish();
			}
		});
		forgot.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(),
						ForgotPass.class);
				startActivity(i);
				finish();
			}
		});
	}
	protected void onStart() {
		super.onStart();
		mGoogleApiClient.connect();
	}

	protected void onStop() {
		super.onStop();
		if (mGoogleApiClient.isConnected()) {
			mGoogleApiClient.disconnect();
		}
	}

	/**
	 * Method to resolve any signin errors
	 * */
	private void resolveSignInError() {
		if (mConnectionResult.hasResolution()) {
			try {
				mIntentInProgress = true;
				mConnectionResult.startResolutionForResult(this, RC_SIGN_IN);
			} catch (IntentSender.SendIntentException e) {
				mIntentInProgress = false;
				mGoogleApiClient.connect();
			}
		}
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		if (!result.hasResolution()) {
			GooglePlayServicesUtil.getErrorDialog(result.getErrorCode(), this,
					0).show();
			return;
		}

		if (!mIntentInProgress) {
			// Store the ConnectionResult for later usage
			mConnectionResult = result;

			if (mSignInClicked) {
				// The user has already clicked 'sign-in' so we attempt to
				// resolve all
				// errors until the user is signed in, or they cancel.
				resolveSignInError();
			}
		}

	}

	@Override
	protected void onResume() {
		super.onResume();


		callbackManager=CallbackManager.Factory.create();

		loginButton= (LoginButton)findViewById(R.id.login_button);

		loginButton.setReadPermissions("public_profile", "email","user_friends");

		btnLogin= (TextView) findViewById(R.id.btnLogin);
		btnLogin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				progressDialog = new ProgressDialog(Login.this);
				progressDialog.setMessage("Loading...");
				progressDialog.show();

				loginButton.performClick();

				loginButton.setPressed(true);

				loginButton.invalidate();

				loginButton.registerCallback(callbackManager, mCallBack);

				loginButton.setPressed(false);

				loginButton.invalidate();

			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == RC_SIGN_IN) {
			if (resultCode != RESULT_OK) {
				mSignInClicked = false;
			}

			mIntentInProgress = false;

			if (!mGoogleApiClient.isConnecting()) {
				mGoogleApiClient.connect();
			}
		}
		else {
			callbackManager.onActivityResult(requestCode, resultCode, data);
		}

	}

	@Override
	public void onConnected(Bundle arg0) {
		mSignInClicked = false;
		Toast.makeText(this, "User is connected!", Toast.LENGTH_LONG).show();

		// Get user's information
		getProfileInformation();

		// Update the UI after signin
		updateUI(true);

	}

	/**
	 * Updating the UI, showing/hiding buttons and profile layout
	 * */
	private void updateUI(boolean isSignedIn) {
		if (isSignedIn) {
			btnSignIn.setVisibility(View.GONE);
			//  btnSignOut.setVisibility(View.VISIBLE);
			//btnRevokeAccess.setVisibility(View.VISIBLE);
			//llProfileLayout.setVisibility(View.VISIBLE);
		} else {
			btnSignIn.setVisibility(View.VISIBLE);
			// btnSignOut.setVisibility(View.GONE);
			// btnRevokeAccess.setVisibility(View.GONE);
			// llProfileLayout.setVisibility(View.GONE);
		}
	}
	private void getProfileInformation() {
		try {
			if (Plus.PeopleApi.getCurrentPerson(mGoogleApiClient) != null) {
				Person currentPerson = Plus.PeopleApi
						.getCurrentPerson(mGoogleApiClient);
				String personName = currentPerson.getDisplayName();
				String personPhotoUrl = currentPerson.getImage().getUrl();
				String personGooglePlusProfile = currentPerson.getUrl();
				String email = Plus.AccountApi.getAccountName(mGoogleApiClient);

				Log.e(TAG, "Name: " + personName + ", plusProfile: "
						+ personGooglePlusProfile + ", email: " + email
						+ ", Image: " + personPhotoUrl);
				Toast.makeText(Login.this, "Name:" + personName + "email:" + email, Toast.LENGTH_LONG).show();
				Intent intent = new Intent(Login.this, Home.class);
				startActivity(intent);
				finish();
				// txtName.setText(personName);
				//  txtEmail.setText(email);

				// by default the profile url gives 50x50 px image only
				// we can replace the value with whatever dimension we want by
				// replacing sz=X
               /* personPhotoUrl = personPhotoUrl.substring(0,
                        personPhotoUrl.length() - 2)
                        + PROFILE_PIC_SIZE;
*/
				//new LoadProfileImage(imgProfilePic).execute(personPhotoUrl);

			} else {
				Toast.makeText(getApplicationContext(),
						"Person information is null", Toast.LENGTH_LONG).show();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onConnectionSuspended(int arg0) {
		mGoogleApiClient.connect();
		updateUI(false);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/**
	 * Button on click listener
	 * */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.btn_sign_in:
				// Signin button clicked
				signInWithGplus();
				break;
            /*case R.id.btn_sign_out:
                // Signout button clicked
                signOutFromGplus();
                break;
            case R.id.btn_revoke_access:
                // Revoke access button clicked
                revokeGplusAccess();
                break;*/
		}
	}

	/**
	 * Sign-in into google
	 * */
	private void signInWithGplus() {
		if (!mGoogleApiClient.isConnecting()) {
			mSignInClicked = true;
			resolveSignInError();

		}
	}

	/**
	 * Sign-out from google
	 * */
	private void signOutFromGplus() {
		if (mGoogleApiClient.isConnected()) {
			Plus.AccountApi.clearDefaultAccount(mGoogleApiClient);
			mGoogleApiClient.disconnect();
			mGoogleApiClient.connect();
			updateUI(false);
		}
	}

	/**
	 * Revoking access from google
	 * */
	private void revokeGplusAccess() {
		if (mGoogleApiClient.isConnected()) {
			Plus.AccountApi.clearDefaultAccount(mGoogleApiClient);
			Plus.AccountApi.revokeAccessAndDisconnect(mGoogleApiClient)
					.setResultCallback(new ResultCallback<Status>() {
						@Override
						public void onResult(Status arg0) {
							Log.e(TAG, "User access revoked!");
							mGoogleApiClient.connect();
							updateUI(false);
						}

					});
		}
	}

	/**
	 * Background Async task to load user profile picture from url
	 * */
	private class LoadProfileImage extends AsyncTask<String, Void, Bitmap> {
		ImageView bmImage;

		public LoadProfileImage(ImageView bmImage) {
			this.bmImage = bmImage;
		}

		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap mIcon11 = null;
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				mIcon11 = BitmapFactory.decodeStream(in);
			} catch (Exception e) {
				Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			return mIcon11;
		}

		protected void onPostExecute(Bitmap result) {
			bmImage.setImageBitmap(result);
		}
	}
	private FacebookCallback<LoginResult> mCallBack = new FacebookCallback<LoginResult>() {
		@Override
		public void onSuccess(LoginResult loginResult) {

			progressDialog.dismiss();

			// App code
			GraphRequest request = GraphRequest.newMeRequest(
					loginResult.getAccessToken(),
					new GraphRequest.GraphJSONObjectCallback() {
						@Override
						public void onCompleted(
								JSONObject object,
								GraphResponse response) {

							Log.e("response: ", response + "");
							try {
								user = new User();
								user.facebookID = object.getString("id").toString();
								user.email = object.getString("email").toString();
								user.name = object.getString("name").toString();
								user.gender = object.getString("gender").toString();
								PrefUtils.setCurrentUser(user,Login.this);

							}catch (Exception e) {
								e.printStackTrace();
							}
							Toast.makeText(Login.this, "fb_id" + user.facebookID + "welcome " + user.name + "email" + user.email + "gender" + user.gender, Toast.LENGTH_LONG).show();
							Intent intent = new Intent(Login.this, Home.class);
							startActivity(intent);
							finish();
                           /* HttpClient httpclient = new DefaultHttpClient();
                            HttpEntity httpEntity = null;
                            String respo = "";
                            HttpPost httppost = new HttpPost("http://www.mazelon.com/preexam/preexam/k2fb.php");
                            try {
                                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
                                nameValuePairs.add(new BasicNameValuePair("&id", user.facebookID));
                                nameValuePairs.add(new BasicNameValuePair("&name", user.name));
                                nameValuePairs.add(new BasicNameValuePair("&email", user.email));
                                nameValuePairs.add(new BasicNameValuePair("&gender", user.gender));

                                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                                // Execute HTTP Post Request
                                HttpResponse resp = httpclient.execute(httppost);
                                httpEntity = resp.getEntity();
                                respo= EntityUtils.toString(httpEntity);
                                if (respo.toLowerCase().equals("success")) {
                                    Toast.makeText(Slider.this, "fb_id" + user.facebookID + "welcome " + user.name + "email" + user.email + "gender" + user.gender, Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(Slider.this, Home.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    AlertDialog.Builder b = new AlertDialog.Builder(
                                            Slider.this);
                                    b.setTitle("Sorry!No Internet Connection!");
                                    b.setPositiveButton("Ok",
                                            new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(DialogInterface arg0,
                                                                    int arg1) {
                                                    // TODO Auto-generated method stub

                                                }
                                            });
                                    b.show();

                                }
                            }catch (Exception e)
                            {

                            }
                            */
						}

					});

			Bundle parameters = new Bundle();
			parameters.putString("fields", "id,name,email,gender, birthday");
			request.setParameters(parameters);
			request.executeAsync();
		}

		@Override
		public void onCancel() {
			progressDialog.dismiss();
		}

		@Override
		public void onError(FacebookException e) {
			progressDialog.dismiss();
		}
	};

	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	boolean loggedIn() {
		try {
			HttpClient httpClient = new DefaultHttpClient();
			HttpResponse httpResponse = null;
			HttpEntity httpEntity = null;
			String response = "";
			HttpPost httpPost = new HttpPost(
					"http://www.mazelon.com/preexam/preexam/k2login.php?email="
							+ username.getText().toString() + "&password="
							+ password.getText().toString());

			httpResponse = httpClient.execute(httpPost);

			httpEntity = httpResponse.getEntity();
			response = EntityUtils.toString(httpEntity);
			response = response.substring(1, response.length() - 1);
			// String[] r = response.split("\\|");
			if (response.toLowerCase().equals("success")) {
				// Global.isLoggedIn = true;
				// Global.user = n;
				// Global.userName = r[0];
				// Global.street = r[1];
				// Global.city = r[2];
				// Global.state = r[3];
				// Global.pincode = r[4];

				SharedPreferences settings = getSharedPreferences("ExamLogin",
						0);
				SharedPreferences.Editor editor = settings.edit();
				// editor.putString("name", n);
				// editor.putString("username", Global.userName);
				// editor.putString("street", Global.street);
				// editor.putString("city", Global.city);
				// editor.putString("state", Global.state);
				// editor.putString("pincode", Global.pincode);

				// editor.putBoolean("logged", true);
				// editor.commit();
				return true;

			} else {
				username.setText("");
				password.setText("");
				AlertDialog.Builder b = new AlertDialog.Builder(
						Login.this);
				b.setTitle("Invalid Username/Password !");
				b.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {

							@Override
							public void onClick(
									DialogInterface arg0, int arg1) {
								// TODO Auto-generated method stub

							}
						});
				b.show();

				Toast.makeText(getApplicationContext(), "Login Failed!",
						Toast.LENGTH_LONG).show();
				return false;
			}
		}catch(UnknownHostException e) {
			Log.d("",e.toString());
			AlertDialog.Builder b = new AlertDialog.Builder(
					Login.this);
			b.setTitle("Sorry you are not connected to the internet !");
			b.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(
								DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub

						}
					});
			b.show();
			return false;
		}
		catch (Exception e) {
			Log.d("", e.toString());
			return false;
		}
	}
	boolean doubleBackToExitPressedOnce = false;

	@Override
	public void onBackPressed() {
		if (doubleBackToExitPressedOnce) {
			super.onBackPressed();
			return;
		}

		this.doubleBackToExitPressedOnce = true;
		Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				doubleBackToExitPressedOnce=false;
			}
		}, 2000);
	}

}
